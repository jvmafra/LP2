package lp2.lab07;


import org.junit.Before;
import org.junit.Test;
import org.junit.Assert;

public class TaxistaTest {

	private Taxista c1;
	private Taxista c2;
	private Taxista c3;

	@Before
	public void setUp() throws Exception {
		c1 = new Taxista("Joao", "001", 200, 2500);
		c2 = new Taxista("Edval", "002", 20000, 100000, 100, 2500);
		
	}
	
	@Test
	public void testConstrutor() {
		Assert.assertEquals("Joao", c1.getNome());
		Assert.assertEquals("Edval", c2.getNome());
		Assert.assertEquals(200, c1.getNumeroDePassageiros());
		Assert.assertEquals(2500, c1.getKMpercorridos());
		Assert.assertEquals(0, c1.getValorCarro(), 0001);
		Assert.assertEquals(20000.0, c2.getValorCarro(), 0.001);
		
		
		try{
			c3 = new Taxista("", "", 0, 0);
			Assert.fail("Deveria lancar excecao");
		} catch(Exception e) {
			Assert.assertEquals("Nome ou numero invalidos", e.getMessage());
		}
		
		try{
			c3 = new Taxista("Joao", "001", -1, 2500);
			Assert.fail("Deveria lancar excecao");
		} catch(Exception e) {
			Assert.assertEquals("Valor invalido.", e.getMessage());
		}
		
		try{
			c3 = new Taxista("Edval", "002", -1, 0, 0, 0);
			Assert.fail("Deveria lancar excecao");
		} catch(Exception e) {
			Assert.assertEquals("Valor invalido.", e.getMessage());
		}
		
		try{
			c3 = new Taxista("Joao", "001", 2000, -1, 200, 500);
			Assert.fail("Deveria lancar excecao");
		} catch(Exception e) {
			Assert.assertEquals("Valor invalido.", e.getMessage());
		}
		
	}
	
	@Test
	public void testaCalculoDoImposto() throws Exception{
		Assert.assertEquals(75.0, c1.computaImposto(), 0.001);
		Assert.assertEquals(25.0, c2.computaImposto(), 0.001);
		c3 = new Taxista("Hugo", "003", 1000, 5543);
		Assert.assertEquals(444.57, c3.computaImposto(), 0.001);
		
	}
	
	@Test
	public void testaEquals() throws Exception{
		Assert.assertFalse(c1.equals(c2));
		c3 = new Taxista("Edval", "002", 20000, 100000, 100, 2500);
		Assert.assertTrue(c2.equals(c3));
		c3 = new Taxista("Edval", "002", 20000, 100000, 100, 23000);
		Assert.assertFalse(c2.equals(c3));
	}
	
	@Test
	public void testaToString() throws Exception{
		Assert.assertEquals("Contribuinte [nome=Edval, numero=002, valorCarro=20000.0, valorCasa=100000.0]\nDados da profissao [numeroDePassageiros=100, KMpercorridos=2500]", c2.toString());
	}

}
