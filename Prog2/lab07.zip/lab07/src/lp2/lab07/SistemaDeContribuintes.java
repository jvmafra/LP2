package lp2.lab07;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class SistemaDeContribuintes {
	
	private List<Contribuinte> contribuintes = new ArrayList<Contribuinte>();
	
	public void adicionaContribuinte(Contribuinte c){
		contribuintes.add(c);
	}
	
	public void removeContribuinte(Contribuinte c){
		contribuintes.remove(c);
	}
	
	public int totalDeContribuintes(){
		return contribuintes.size();
	}
	
	public Contribuinte pesquisaContribuinte(String nome){
		Iterator<Contribuinte> it = contribuintes.iterator();
		while(it.hasNext()) {
			Contribuinte umContribuinte = it.next();
			if(umContribuinte.getNome().equals(nome))
				return umContribuinte;
		}
		
		return null;
	}
	
	public String toStringCalculaImpostoContribuinte(String nome){
		Contribuinte contribuinte = pesquisaContribuinte(nome);
		
		return "Total a ser pago: R$ " + contribuinte.computaImposto();
	}
	
	
}
