package lp2.lab07;

public class Taxista extends Contribuinte{
	private int numeroDePassageiros;
	private int KMpercorridos;
	
	public Taxista (String nome, String numero, double valorCarro, double valorCasa, int numeroDePassageiros, int KMpercorridos) throws Exception{
		super(nome, numero, valorCarro, valorCasa);
		
		if (KMpercorridos < 0 || numeroDePassageiros < 0)
			throw new Exception("Valor invalido.");
		
		this.KMpercorridos = KMpercorridos;
		this.numeroDePassageiros = numeroDePassageiros;
	}
	
	public Taxista (String nome, String numero, int numeroDePassageiros, int KMpercorridos) throws Exception{
		this(nome, numero, 0, 0, numeroDePassageiros, KMpercorridos);
	}

	public int getNumeroDePassageiros() {
		return numeroDePassageiros;
	}

	public int getKMpercorridos() {
		return KMpercorridos;
	}
	
	public double computaImposto(){
		double tributado = calculaTributado();
		double descontos = calculaDescontos();
		double imposto = tributado - descontos;
		
		if (imposto <= 0)
			return 0.0;
		
		return imposto;
	}

	private double calculaDescontos() {
		double descontos = 0.01 * getKMpercorridos();
		return descontos;
	}

	private double calculaTributado() {
		double tributado = 0.5 * getNumeroDePassageiros();
		return tributado;
	}

	@Override
	public String toString() {
		return super.toString() + "\nDados da profissao [numeroDePassageiros=" + numeroDePassageiros
				+ ", KMpercorridos=" + KMpercorridos + "]";
	}
	
	@Override
	public boolean equals(Object obj){
		if (!(obj instanceof Taxista))
			return false;
		
		Contribuinte contribuinte = (Contribuinte) obj;
		Taxista taxista = (Taxista) obj;
		
		return super.equals(contribuinte) && getNumeroDePassageiros() == taxista.getNumeroDePassageiros() && getKMpercorridos() == taxista.getKMpercorridos();
		
	}
	
	
	
}
