package lp2.lab07;

public class Medico extends Contribuinte{
	private int numeroDePacientes;
	private double despesaCongressos;
	
	public Medico(String nome, String numero, double valorCarro, double valorCasa, int numeroDePacientes, double despesaCongressos) throws Exception{
		super(nome, numero, valorCarro, valorCasa);
		
		if (numeroDePacientes < 0 || despesaCongressos < 0)
			throw new Exception("Valor invalido.");
		
		this.numeroDePacientes = numeroDePacientes;
		this.despesaCongressos = despesaCongressos;
		
	}

	public int getNumeroDePacientes() {
		return numeroDePacientes;
	}

	public double getDespesaCongressos() {
		return despesaCongressos;
	}
	
	public double computaImposto() {
		double tributado = calculaTributado();
		double descontos = calculaDescontos();
		double imposto = tributado - descontos;
		
		if (imposto <= 0)
			return 0.0;
		
		return imposto;
	}

	private double calculaDescontos() {
		double descontos = getDespesaCongressos();
		return descontos;
	}

	private double calculaTributado() {
		double tributado = getNumeroDePacientes() * 10;
		return tributado;
	}

	@Override
	public String toString() {
		return super.toString() + "\nDados da profissao [numeroDePacientes=" + numeroDePacientes
				+ ", despesaCongressos=" + despesaCongressos + "]";
	}
	
	@Override
	public boolean equals(Object obj){
		if (!(obj instanceof Medico))
			return false;
		
		Contribuinte contribuinte = (Contribuinte) obj;
		Medico medico = (Medico) obj;
		
		return super.equals(contribuinte) && getNumeroDePacientes() == medico.getNumeroDePacientes() && getDespesaCongressos() == medico.getDespesaCongressos();
	}
	
	
}
