package lp2.lab07;

public abstract class Contribuinte {
	private String nome;
	private String numero;
	private double valorCarro = 0.0;
	private double valorCasa = 0.0;
	
	public Contribuinte (String nome, String numero, double valorCarro, double valorCasa) throws Exception {
		if (nome.equals("") || numero.equals(""))
			throw new Exception("Nome ou numero invalidos");
		if (valorCarro < 0 || valorCasa < 0)
			throw new Exception("Valor invalido.");
		
		this.nome = nome;
		this.numero = numero;
		this.valorCarro = valorCarro;
		this.valorCasa = valorCasa;
	}
	
	public Contribuinte (String nome, String numero) throws Exception{
		this(nome, numero, 0, 0);
	}
	
	public abstract double computaImposto();


	public String getNome() {
		return nome;
	}

	public String getNumero() {
		return numero;
	}

	public double getValorCarro() {
		return valorCarro;
	}

	public double getValorCasa() {
		return valorCasa;
	}

	@Override
	public String toString() {
		return "Contribuinte [nome=" + nome + ", numero=" + numero
				+ ", valorCarro=" + valorCarro + ", valorCasa=" + valorCasa
				+ "]";
	}
	
	@Override
	public boolean equals(Object obj){
		if (!(obj instanceof Contribuinte))
			return false;
		
		Contribuinte outroContribuinte = (Contribuinte) obj;
		
		return getNome().equals(outroContribuinte.getNome()) && getNumero().equals(outroContribuinte.getNumero()) 
				&& getValorCarro() == outroContribuinte.getValorCarro() && getValorCasa() == outroContribuinte.getValorCasa();
				
		
	}
	

}
