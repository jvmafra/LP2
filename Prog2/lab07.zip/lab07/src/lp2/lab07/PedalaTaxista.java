package lp2.lab07;

public class PedalaTaxista {
	public static void main(String args[]) throws Exception{
		Contribuinte c1 = new Taxista("Joao", "001", 200, 2500);
		Contribuinte c2 = new Taxista("Edval", "002", 20000, 100000, 100, 2500);
		Contribuinte c3 = new Taxista("Hugo", "003", 1000, 5543);
		
		System.out.println(c1.computaImposto());
		System.out.println(c2.computaImposto());
		System.out.println(c3.computaImposto());
		System.out.println(c2.toString());
	}

}
