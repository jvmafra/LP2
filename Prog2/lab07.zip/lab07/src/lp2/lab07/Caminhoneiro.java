package lp2.lab07;

public class Caminhoneiro extends Contribuinte{
	private int toneladas;
	private int KMPercorridos;
	
	public Caminhoneiro (String nome, String numero, double valorCarro, double valorCasa, int KMPercorridos, int toneladas) throws Exception{
		super(nome, numero, valorCarro, valorCasa);
		
		if (toneladas < 0 || KMPercorridos < 0)
			throw new Exception("Valor invalido.");
		
		this.toneladas = toneladas;
		this.KMPercorridos = KMPercorridos;
		
	}

	public int getToneladas() {
		return toneladas;
	}

	public int getKMPercorridos() {
		return KMPercorridos;
	}
	
	@Override
	public double computaImposto(){
		double tributado = calculaTributado();
		double descontos = calculaDescontos();
		double imposto = tributado - descontos;
		
		if (imposto <= 0)
			return 0.0;
		
		return imposto;
	}
	
	private double calculaTributado(){
		if (getToneladas() <= 10)
				return 500;
		else
			return 500 + (getToneladas() - 10) * 100;
	}
	
	private double calculaDescontos(){
		double descontos = 0.01 * getKMPercorridos();
		return descontos;
	}
	
	@Override
	public String toString() {
		return super.toString() + "\nDados da profissao [toneladas=" + toneladas + ", KMPercorridos="
				+ KMPercorridos + "]";
	}
	
	@Override
	public boolean equals(Object obj){
		if (!(obj instanceof Caminhoneiro))
			return false;
		
		Contribuinte contribuinte = (Contribuinte) obj;
		Caminhoneiro caminhoneiro = (Caminhoneiro) obj;
		
		return super.equals(contribuinte) && getToneladas() == caminhoneiro.getToneladas() && getKMPercorridos() == caminhoneiro.getKMPercorridos();
	}
	

	
	
}
