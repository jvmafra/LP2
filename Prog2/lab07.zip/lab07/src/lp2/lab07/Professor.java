package lp2.lab07;

public class Professor extends Contribuinte {
	private double salario;
	private double despesaMaterialDidatico;
	public static final double SALARIO_MINIMO = 724.0;
	
	public Professor(String nome, String numero, double valorCarro, double valorCasa, double salario, double despesaMaterialDidatico) throws Exception{
		super(nome, numero, valorCarro, valorCasa);
		
		if (salario < 0 || despesaMaterialDidatico < 0)
			throw new Exception("Valor invalido.");
		
		this.salario = salario;
		this.despesaMaterialDidatico = despesaMaterialDidatico;
	}

	public double getSalario() {
		return salario;
	}

	public double getDespesaMaterialDidatico() {
		return despesaMaterialDidatico;
	}
	
	public double computaImposto() {
		double tributado = calculaTributado();
		double descontos = calculaDescontos();
		double imposto = tributado - descontos;
		
		if (imposto <= 0)
			return 0.0;
		
		return imposto;	
	}

	private double calculaDescontos() {
		double descontos = 0.5 * despesaMaterialDidatico;
		return descontos;
	}

	private double calculaTributado(){
		if (getSalario() <= Professor.SALARIO_MINIMO)
			return 0.05 * getSalario();
		
		else if (getSalario() <= 5 * Professor.SALARIO_MINIMO)
			return 0.1 * getSalario();
		else
			return 0.2 * getSalario();
	}

	@Override
	public String toString() {
		return super.toString() + "\nDados da profissao [salario=" + salario + ", despesaMaterialDidatico="
				+ despesaMaterialDidatico + "]";
	}
	
	@Override
	public boolean equals(Object obj){
		if (!(obj instanceof Professor))
			return false;
		
		Contribuinte contribuinte = (Contribuinte) obj;
		Professor professor = (Professor) obj;
		
		return super.equals(contribuinte) && getSalario() == professor.getSalario() && getDespesaMaterialDidatico() == professor.getDespesaMaterialDidatico();
	}
	
	
	
}
